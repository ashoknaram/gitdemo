package com.ojas.springboot.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ojas.springboot.entity.Plans;
import com.ojas.springboot.repository.MediaFireRepository;


@RestController
public class MediaFireController {
	@Autowired
	private MediaFireRepository repo;
	@PostMapping("/add")
	public Plans addplan(@RequestBody Plans plan) {
		
		return repo.save(plan);
		
	}
	@GetMapping("/list")
	public List<Plans>viewall(){
		return repo.findAll();
	}
//	update(@RequestBody Plans plan) {
//		return service.update(null);@DeleteMapping("delete/{id}")
//	public void delete(@PathVariable("id") int id) {
//	service.deleteplan(id);
//	}
//	@GetMapping("viewbyid{id}")
//	public Optional<Plans> viewbyid(@PathVariable("id") int id){
//		return service.editby(id);
//	}
//	@PostMapping("/update")
//	public Plans 
//	}

}
