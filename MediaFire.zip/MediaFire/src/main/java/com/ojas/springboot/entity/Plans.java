package com.ojas.springboot.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Plans {
	@Id
	private int id;
	private double price;
	private double storage;

	private String planName;
	public Plans() {
		super();
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public double getStorage() {
		return storage;
	}
	public void setStorage(double storage) {
		this.storage = storage;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public Plans(int id, double price, double storage, String planName) {
		
		this.id = id;
		this.price = price;
		this.storage = storage;
		this.planName = planName;
	}
	
	

}
